# KODY LAIR ☠

Kody's personal den on the internet — black and red, nu metal certified.

**Zero dependencies.** No npm install needed — just Node.js.

## Run it

```bash
cd kody-lair
node server.js        # or: npm start
```

- Public site: **http://localhost:3000/**
- Backstage (control app): **http://localhost:3000/admin**
- Optional port: `PORT=8080 node server.js`

## First login

Backstage password: **`maggot`**

Change it immediately in **SETTINGS → CHANGE PASSWORD**.
(Changing it logs out every other device.)

## What the backstage app controls

| Tab | What it does |
|---|---|
| TRANSMISSIONS | Post real-time notes → appear on the public site within seconds. Each note **self-destructs after exactly 24 hours**. |
| COVERS | Add guitar covers via **YouTube link** or **file upload** (video/audio, max 500MB). Uploaded files play in an in-site player. |
| PROFILE | Edit your **bio** (name, tagline, favorite bands, story) and your **hobbies** list (any emoji as icon). |
| SETTINGS | Change the password. |

The public site polls every few seconds, so anything you post backstage
shows up for viewers almost instantly — no refresh needed.

## Where everything lives

```
kody-lair/
├── server.js          # the whole server (no dependencies)
├── public/
│   ├── index.html     # the public site
│   └── admin.html     # the backstage app
├── data/data.json     # bio, hobbies, covers, notes  (your content)
└── uploads/           # uploaded cover files
```

Back up `data/` + `uploads/` and you've backed up the whole lair.

## Notes

- Notes older than 24 hours are purged automatically.
- Deleting a cover also deletes its uploaded file.
- Very large uploads may not survive server restarts in some hosting
  setups — YouTube links are the bulletproof option.
