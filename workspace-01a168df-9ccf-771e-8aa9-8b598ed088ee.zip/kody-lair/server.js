#!/usr/bin/env node
/*
 * KODY LAIR — zero-dependency server
 *
 *   /        public site   (public/index.html)
 *   /admin   backstage app (public/admin.html)
 *
 *   data:     data/data.json
 *   uploads:  uploads/
 *
 * No npm packages needed. Just:  node server.js
 */
'use strict';

const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

const ROOT     = __dirname;
const PUB_DIR  = path.join(ROOT, 'public');
const UP_DIR   = path.join(ROOT, 'uploads');
const DATA_DIR = path.join(ROOT, 'data');
const DATA     = path.join(DATA_DIR, 'data.json');

const PORT       = process.env.PORT || 3000;
const HOST       = '0.0.0.0';
const DAY_MS     = 24 * 60 * 60 * 1000;   // notes live exactly one day
const NOTE_MAX   = 1000;                  // max note length (chars)
const MAX_JSON   = 1024 * 1024;           // 1MB for JSON bodies
const MAX_UPLOAD = 500 * 1024 * 1024;     // 500MB for cover uploads

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UP_DIR, { recursive: true });

const uid    = () => crypto.randomUUID();
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

/* --------------------------------- database -------------------------------- */

function defaultDb() {
  return {
    password: sha256('maggot'),
    bio: {
      name: 'KODY',
      tagline: 'WELCOME TO THE LAIR — POPULATION: YOU',
      bio: "I'm Kody. I play guitar until my fingers file restraining orders.\nI was raised on nu metal and I never recovered — if it dropped after 1994 and there's a wall of downtuned guitars in it, I probably know it by heart.\nThis site is my den: notes here self-destruct after 24 hours, the covers live forever, and the door never closes. Pull up a speaker."
    },
    music: {
      bands: ['Korn', 'Deftones', 'Slipknot', 'System of a Down', 'Limp Bizkit', 'Mudvayne', 'Linkin Park'],
      songs: []
    },
    hobbies: [
      { icon: '🎸', title: 'Riffing',              desc: 'Downtuned. Distorted. Dangerously loud.' },
      { icon: '🎧', title: 'Digging For B-Sides',  desc: 'Hunting deep cuts, demos and bootlegs.' },
      { icon: '📼', title: 'Collecting Records',   desc: 'CDs too. Physical media never died here.' },
      { icon: '🎮', title: 'Gaming',               desc: 'Die. Respawn. Repeat.' },
      { icon: '✍',  title: 'Daily Transmissions', desc: 'Notes from the lair. Gone in 24 hours.' }
    ],
    covers: [],
    notes: []
  };
}

function loadDb() {
  try {
    const d = JSON.parse(fs.readFileSync(DATA, 'utf8'));
    const def = defaultDb();
    const db = Object.assign(def, d, { bio: Object.assign(def.bio, d.bio || {}) });
    if (!d.music) {
      // first run since the MUSIC update — adopt bands from the old bio field if present
      db.music = {
        bands: String((db.bio.bands || '')).split('·').map((s) => s.trim()).filter(Boolean),
        songs: []
      };
      fs.writeFileSync(DATA, JSON.stringify(db, null, 2));
    } else {
      db.music = Object.assign({ bands: [], songs: [] }, d.music);
    }
    return db;
  } catch (e) {
    const d = defaultDb();
    fs.writeFileSync(DATA, JSON.stringify(d, null, 2));
    return d;
  }
}

const DB = loadDb();
function saveDb() { fs.writeFileSync(DATA, JSON.stringify(DB, null, 2)); }

const SESSIONS = new Set();
function isAuthed(req) {
  const t = String(req.headers['x-auth-token'] || '');
  return !!t && SESSIONS.has(t);
}

function purgeExpired() {
  const now = Date.now();
  const before = DB.notes.length;
  DB.notes = DB.notes.filter((n) => now - n.createdAt < DAY_MS);
  if (DB.notes.length !== before) saveDb();
}

function publicData() {
  const now = Date.now();
  return {
    ok: true,
    serverTime: now,
    bio: DB.bio,
    hobbies: DB.hobbies,
    music: DB.music,
    covers: DB.covers,
    notes: DB.notes
      .filter((n) => now - n.createdAt < DAY_MS)
      .sort((a, b) => b.createdAt - a.createdAt)
      .map((n) => ({ id: n.id, text: n.text, createdAt: n.createdAt, expiresAt: n.createdAt + DAY_MS }))
  };
}

/* ---------------------------------- helpers -------------------------------- */

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let chunks = [], len = 0, over = false;
    req.on('data', (c) => {
      if (over) return;
      len += c.length;
      if (len > limit) {
        over = true;
        const e = new Error('payload too large'); e.status = 413;
        reject(e); req.destroy(); return;
      }
      chunks.push(c);
    });
    req.on('end', () => { if (!over) resolve(Buffer.concat(chunks)); });
    req.on('error', (e) => { if (!over) { over = true; reject(e); } });
  });
}

async function readJson(req) {
  const buf = await readBody(req, MAX_JSON);
  try { return JSON.parse(buf.toString('utf8') || '{}'); }
  catch (e) { const err = new Error('invalid JSON'); err.status = 400; throw err; }
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'text/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt':  'text/plain; charset=utf-8',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif':  'image/gif',
  '.webp': 'image/webp',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.mp4':  'video/mp4',
  '.m4v':  'video/mp4',
  '.webm': 'video/webm',
  '.mov':  'video/quicktime',
  '.ogv':  'video/ogg',
  '.ogg':  'audio/ogg',
  '.mp3':  'audio/mpeg',
  '.wav':  'audio/wav',
  '.flac': 'audio/flac',
  '.m4a':  'audio/mp4'
};

function serveFile(req, res, dir, rel) {
  const p = path.normalize(path.join(dir, rel));
  if (p !== dir && !p.startsWith(dir + path.sep)) return json(res, 403, { error: 'forbidden' });
  let st;
  try { st = fs.statSync(p); } catch (e) { return json(res, 404, { error: 'not found' }); }
  if (st.isDirectory()) return json(res, 404, { error: 'not found' });
  const ext  = path.extname(p).toLowerCase();
  const mime = MIME[ext] || 'application/octet-stream';
  const headers = {
    'Content-Type': mime,
    'Accept-Ranges': 'bytes',
    'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600'
  };
  const range = req.headers.range;
  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(String(range).trim());
    if (m && (m[1] !== '' || m[2] !== '')) {
      let start = m[1] === '' ? 0 : parseInt(m[1], 10);
      let end   = m[2] === '' ? st.size - 1 : parseInt(m[2], 10);
      if (m[1] === '' && m[2] !== '') { start = Math.max(0, st.size - end); end = st.size - 1; } // suffix range
      if (isNaN(start) || isNaN(end) || start > end || start >= st.size) {
        res.writeHead(416, { 'Content-Range': 'bytes */' + st.size });
        return res.end();
      }
      end = Math.min(end, st.size - 1);
      res.writeHead(206, Object.assign(headers, {
        'Content-Range': 'bytes ' + start + '-' + end + '/' + st.size,
        'Content-Length': end - start + 1
      }));
      return fs.createReadStream(p, { start, end }).pipe(res);
    }
  }
  res.writeHead(200, Object.assign(headers, { 'Content-Length': st.size }));
  fs.createReadStream(p).pipe(res);
}

function ytId(input) {
  const s = String(input || '').trim();
  if (!s) return null;
  const m = /(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|shorts\/|embed\/|live\/|v\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/.exec(s);
  if (m) return m[1];
  if (/^[A-Za-z0-9_-]{11}$/.test(s)) return s; // a raw video id also works
  return null;
}

/* Streams an upload straight to disk, enforcing the size cap. */
function saveStream(req, res, dest, limit) {
  return new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(dest);
    let len = 0, over = false;
    req.on('data', (c) => {
      if (over) return;
      len += c.length;
      if (len > limit) {
        over = true;
        const e = new Error('file too large (max 500MB)'); e.status = 413; e.sent = true;
        try { ws.destroy(); fs.unlinkSync(dest); } catch (_) {}
        json(res, 413, { error: e.message });
        reject(e);
        req.destroy();
      }
    });
    ws.on('error', (e2) => {
      if (!over) { over = true; try { fs.unlinkSync(dest); } catch (_) {} reject(e2); }
    });
    ws.on('finish', () => { if (!over) resolve(len); });
    req.pipe(ws);
  });
}

/* ---------------------------------- server --------------------------------- */

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://kody.local');
    const p = u.pathname;
    const method = req.method;

    /* ---------- public ---------- */
    if (method === 'GET') {
      if (p === '/' || p === '/index.html')            return serveFile(req, res, PUB_DIR, 'index.html');
      if (p === '/admin' || p === '/admin/')           return serveFile(req, res, PUB_DIR, 'admin.html');
      if (p === '/api/public')                        { purgeExpired(); return json(res, 200, publicData()); }
      if (p === '/api/health')                        return json(res, 200, { ok: true });
      if (p.startsWith('/uploads/'))                  return serveFile(req, res, UP_DIR, decodeURIComponent(p.slice('/uploads/'.length)));
      if (p.startsWith('/public/'))                   return serveFile(req, res, PUB_DIR, p.slice('/public/'.length));
      if (p === '/favicon.ico')                       { res.writeHead(204); return res.end(); }
      return json(res, 404, { error: 'not found' });
    }

    /* ---------- login ---------- */
    if (p === '/api/login' && method === 'POST') {
      const b = await readJson(req);
      const given = String(b.password || '').trim();
      // exact match first, then forgiving lowercase match (mobile keyboards love to capitalize)
      if (sha256(given) === DB.password || sha256(given.toLowerCase()) === DB.password) {
        const t = uid(); SESSIONS.add(t);
        return json(res, 200, { ok: true, token: t });
      }
      return json(res, 401, { error: 'wrong password' });
    }

    /* ---------- everything below is backstage-only ---------- */
    if (!isAuthed(req)) return json(res, 401, { error: 'unauthorized' });

    if (method === 'POST') {
      if (p === '/api/logout') {
        SESSIONS.delete(String(req.headers['x-auth-token'] || ''));
        return json(res, 200, { ok: true });
      }
      if (p === '/api/verify') return json(res, 200, { ok: true });

      /* notes */
      if (p === '/api/notes') {
        const b = await readJson(req);
        const text = String(b.text || '').trim().slice(0, NOTE_MAX);
        if (!text) return json(res, 400, { error: 'note is empty' });
        const note = { id: uid(), text, createdAt: Date.now() };
        DB.notes.push(note);
        purgeExpired(); saveDb();
        return json(res, 200, { ok: true, note });
      }

      /* covers — youtube link */
      if (p === '/api/covers') {
        const b = await readJson(req);
        const title = String(b.title || '').trim().slice(0, 120);
        if (!title) return json(res, 400, { error: 'title required' });
        const yid = ytId(b.youtubeUrl || b.url || b.youtubeId || '');
        if (!yid) return json(res, 400, { error: 'that does not look like a YouTube link' });
        const cover = {
          id: uid(), type: 'youtube', title,
          description: String(b.description || '').trim().slice(0, 500),
          youtubeId: yid, createdAt: Date.now()
        };
        DB.covers.unshift(cover); saveDb();
        return json(res, 200, { ok: true, cover });
      }

      /* covers — raw file upload (title/filename ride in the headers) */
      if (p === '/api/covers/upload') {
        const dec = (h) => { try { return decodeURIComponent(String(req.headers[h] || '')); } catch (e) { return ''; } };
        const title       = dec('x-title').trim().slice(0, 120);
        const description = dec('x-description').trim().slice(0, 500);
        const rawName     = dec('x-filename') || 'cover';
        if (!title) return json(res, 400, { error: 'title required' });
        let ext = path.extname(rawName).toLowerCase();
        if (!/^\.[a-z0-9]{2,5}$/.test(ext)) ext = '.mp4';
        const fname = uid().slice(0, 8) + '-' + Date.now() + ext;
        let size = 0;
        try {
          size = await saveStream(req, res, path.join(UP_DIR, fname), MAX_UPLOAD);
        } catch (e) {
          if (e.sent || res.headersSent) return;
          return json(res, e.status || 500, { error: e.message || 'upload failed' });
        }
        const cover = { id: uid(), type: 'file', title, description, file: fname, size, createdAt: Date.now() };
        DB.covers.unshift(cover); saveDb();
        return json(res, 200, { ok: true, cover });
      }

      /* bio */
      if (p === '/api/bio') {
        const b = await readJson(req);
        DB.bio = {
          name:    String(b.name || '').trim().slice(0, 60) || 'KODY',
          tagline: String(b.tagline || '').trim().slice(0, 140),
          bio:     String(b.bio || '').slice(0, 5000),
          bands:   String(b.bands || '').trim().slice(0, 300)
        };
        saveDb(); return json(res, 200, { ok: true });
      }

      /* hobbies */
      if (p === '/api/hobbies') {
        const b = await readJson(req);
        if (!Array.isArray(b.hobbies)) return json(res, 400, { error: 'bad payload' });
        DB.hobbies = b.hobbies.slice(0, 24).map((h) => ({
          icon:  String((h && h.icon)  || '').trim().slice(0, 12),
          title: String((h && h.title) || '').trim().slice(0, 80),
          desc:  String((h && h.desc)  || '').trim().slice(0, 300)
        })).filter((h) => h.title);
        saveDb(); return json(res, 200, { ok: true });
      }

      /* music — favorite bands + mixtape */
      if (p === '/api/music') {
        const b = await readJson(req);
        if (!b || typeof b !== 'object') return json(res, 400, { error: 'bad payload' });
        const bands = Array.isArray(b.bands)
          ? b.bands.slice(0, 60).map((x) => String(x || '').trim().slice(0, 60)).filter(Boolean)
          : DB.music.bands;
        const songs = Array.isArray(b.songs)
          ? b.songs.slice(0, 100).map((s) => ({
              title:  String((s && s.title)  || '').trim().slice(0, 120),
              artist: String((s && s.artist) || '').trim().slice(0, 120),
              link:   /^https?:\/\//i.test(String((s && s.link) || '').trim()) ? String(s.link).trim().slice(0, 500) : ''
            })).filter((s) => s.title)
          : DB.music.songs;
        DB.music = { bands, songs };
        saveDb(); return json(res, 200, { ok: true });
      }

      /* change password */
      if (p === '/api/password') {
        const b = await readJson(req);
        const cur = String(b.current || '').trim();
        if (sha256(cur) !== DB.password && sha256(cur.toLowerCase()) !== DB.password)
          return json(res, 403, { error: 'current password is wrong' });
        const next = String(b.next || '').trim();
        if (next.length < 4) return json(res, 400, { error: 'new password must be at least 4 characters' });
        DB.password = sha256(next); saveDb();
        const t = uid(); SESSIONS.clear(); SESSIONS.add(t); // fresh session for the current user
        return json(res, 200, { ok: true, token: t });
      }
    }

    if (method === 'DELETE') {
      if (p.startsWith('/api/notes/')) {
        const id = p.slice('/api/notes/'.length);
        DB.notes = DB.notes.filter((n) => n.id !== id);
        saveDb(); return json(res, 200, { ok: true });
      }
      if (p.startsWith('/api/covers/')) {
        const id = p.slice('/api/covers/'.length);
        const c = DB.covers.find((x) => x.id === id);
        if (c && c.file) { try { fs.unlinkSync(path.join(UP_DIR, c.file)); } catch (_) {} }
        DB.covers = DB.covers.filter((x) => x.id !== id);
        saveDb(); return json(res, 200, { ok: true });
      }
    }

    return json(res, 404, { error: 'not found' });
  } catch (err) {
    console.error('!', err);
    if (!res.headersSent) json(res, err.status || 500, { error: err.message || 'server error' });
  }
});

/* allow slow, fat uploads */
server.requestTimeout = 0;
server.headersTimeout = 65000;

server.listen(PORT, HOST, () => {
  console.log('');
  console.log('  ☠  KODY LAIR is online');
  console.log('     public site : http://localhost:' + PORT + '/');
  console.log('     backstage   : http://localhost:' + PORT + '/admin');
  console.log('     first login : password "maggot" (change it in SETTINGS)');
  console.log('');
});
